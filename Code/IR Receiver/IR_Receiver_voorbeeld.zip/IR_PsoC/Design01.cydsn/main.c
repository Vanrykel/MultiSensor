/* ========================================
 *
 * Copyright Oztronics, 2013
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Oztronics.
 *
 * ========================================
*/
#include <project.h>


#define LED_ON 0u
#define LED_OFF 1u



uint16 ir_val;		    /* IR Value */
uint8 cnt = 0u;         /* # of raw (unfiltered)transitions of input pin 'SW' */
uint8 ledstatus = 0u;   /* LED status */

extern uint8 count;
extern uint8 temp[12];
uint8 i = 0;

int main()
{
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    
    ShiftReg_Start();
	PWM_Start();
    UART_1_Start();
    UART_1_UartPutString("Watermeloen");
    
//    CYGlobalIntEnable; /* Uncomment this line to enable global interrupts. */
    
    
    for(;;)
    {
            
            /* This just toggles the RED LED - and will be removed later */
            /* The goal is to get the latter part of this code to recognize */
			
            if(0u != P0_6_Read())
			{
		    
            }
            
          
			    {
			    ledstatus = Pin_RedLED_Read();
			    if (ledstatus == 0) 
			    {
				    ledstatus = 1;
                    UART_1_UartPutChar('1');
			    }
			    else
			    {
				    ledstatus = 0;
                    UART_1_UartPutChar('0');
			    }
			    Pin_RedLED_Write(ledstatus);
    }
}
}

/* [] END OF FILE */
