/*******************************************************************************
* File Name: dec_out.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_dec_out_H) /* Pins dec_out_H */
#define CY_PINS_dec_out_H

#include "cytypes.h"
#include "cyfitter.h"
#include "dec_out_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} dec_out_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   dec_out_Read(void);
void    dec_out_Write(uint8 value);
uint8   dec_out_ReadDataReg(void);
#if defined(dec_out__PC) || (CY_PSOC4_4200L) 
    void    dec_out_SetDriveMode(uint8 mode);
#endif
void    dec_out_SetInterruptMode(uint16 position, uint16 mode);
uint8   dec_out_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void dec_out_Sleep(void); 
void dec_out_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(dec_out__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define dec_out_DRIVE_MODE_BITS        (3)
    #define dec_out_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - dec_out_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the dec_out_SetDriveMode() function.
         *  @{
         */
        #define dec_out_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define dec_out_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define dec_out_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define dec_out_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define dec_out_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define dec_out_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define dec_out_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define dec_out_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define dec_out_MASK               dec_out__MASK
#define dec_out_SHIFT              dec_out__SHIFT
#define dec_out_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in dec_out_SetInterruptMode() function.
     *  @{
     */
        #define dec_out_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define dec_out_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define dec_out_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define dec_out_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(dec_out__SIO)
    #define dec_out_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(dec_out__PC) && (CY_PSOC4_4200L)
    #define dec_out_USBIO_ENABLE               ((uint32)0x80000000u)
    #define dec_out_USBIO_DISABLE              ((uint32)(~dec_out_USBIO_ENABLE))
    #define dec_out_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define dec_out_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define dec_out_USBIO_ENTER_SLEEP          ((uint32)((1u << dec_out_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << dec_out_USBIO_SUSPEND_DEL_SHIFT)))
    #define dec_out_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << dec_out_USBIO_SUSPEND_SHIFT)))
    #define dec_out_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << dec_out_USBIO_SUSPEND_DEL_SHIFT)))
    #define dec_out_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(dec_out__PC)
    /* Port Configuration */
    #define dec_out_PC                 (* (reg32 *) dec_out__PC)
#endif
/* Pin State */
#define dec_out_PS                     (* (reg32 *) dec_out__PS)
/* Data Register */
#define dec_out_DR                     (* (reg32 *) dec_out__DR)
/* Input Buffer Disable Override */
#define dec_out_INP_DIS                (* (reg32 *) dec_out__PC2)

/* Interrupt configuration Registers */
#define dec_out_INTCFG                 (* (reg32 *) dec_out__INTCFG)
#define dec_out_INTSTAT                (* (reg32 *) dec_out__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define dec_out_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(dec_out__SIO)
    #define dec_out_SIO_REG            (* (reg32 *) dec_out__SIO)
#endif /* (dec_out__SIO_CFG) */

/* USBIO registers */
#if !defined(dec_out__PC) && (CY_PSOC4_4200L)
    #define dec_out_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define dec_out_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define dec_out_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define dec_out_DRIVE_MODE_SHIFT       (0x00u)
#define dec_out_DRIVE_MODE_MASK        (0x07u << dec_out_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins dec_out_H */


/* [] END OF FILE */
