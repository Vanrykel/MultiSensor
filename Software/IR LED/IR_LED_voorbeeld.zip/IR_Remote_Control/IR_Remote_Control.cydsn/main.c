/*******************************************************************************
* File Name: main.c
*
* Version: 1.0
*
* Description:
*  This example demonstrates how the PSoC 4 pioneer kit can be used to make an 
*  RC-5 infrared remote control, implementing manchester coding and pulse coding
*  using 2 TCPWM blocks. 
*  
*  - The push button SW2 (P0[7]) on the pioneer kit is used to decrease the 
*    screen brightness of an RC-5 operated device.
*  - The capsense slider (P1[4:0], P4[2]) on the pioneer kit is used to control the 
*    volume of an RC-5 device.
*  
*  This example uses TV1 (TV receiver 1) system as the target address. The 
*  target address can be changed to access different types of RC-5 devices.
*  
*  The commands can be changed to modify the type of operation that the button
*  push and the capense slider executes.
*
* Expected Output:
*  36 kHz, 20% duty cycle pulse-coded carrier.
*  562.4 Hz Manchester coded data.
*  Full packet transmission time of 24.9 ms.
*  Auto repeat time of 114 ms.
*
********************************************************************************
* Copyright 2013, Cypress Semiconductor Corporation. All rights reserved.
* This software is owned by Cypress Semiconductor Corporation and is protected
* by and subject to worldwide patent and copyright laws and treaties.
* Therefore, you may use this software only as provided in the license agreement
* accompanying the software package from which you obtained this software.
* CYPRESS AND ITS SUPPLIERS MAKE NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* WITH REGARD TO THIS SOFTWARE, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT,
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*******************************************************************************/

#include <device.h>

/* Set to TV address 1 */
#define TARGET_ADDRESS  0x00u

/* Button press - Decrease screen brightness */
#define SYSTEM_COMMAND_0    0x13u

/* Capsense slider - Increase volume */
#define SYSTEM_COMMAND_1    0x0Fu

/* Capsense slider - Decrease volume */
#define SYSTEM_COMMAND_2    0x10u

/* Shifts and masks */
#define ADDRESS_MASK    0x10u
#define ADDRESS_SHIFT   0x04u
#define COMMAND_MASK    0x20u
#define COMMAND_SHIFT   0x05u

/* Packet variables */
uint8 startBit = 0x01u;
uint8 fieldBit = 0x01u;
uint8 controlBit = 0x00u;
uint8 address, addressBit;
uint8 command, commandBit;

/* Control variables */
uint8 previousCommand = 0u;
uint8 transmitState = 0u;
uint8 buttonState = 0u;
uint8 buttonRelease = 0u;
uint8 autoRepeat = 0u;
uint8 capsenseInitial = 1u;
uint16 curPos, oldPos;


/*******************************************************************************
* Function Name: CY_ISR(BRIGHTNESS)
********************************************************************************
*
* Summary:
*  Button press for the "decrease brightness" command.
*
* Parameters:
*  None.
* 
* Return: 
*  None.
*
*******************************************************************************/
CY_ISR(BRIGHTNESS)
{   
    if((buttonState != 1u) && (!capsenseInitial))
    {
        address = TARGET_ADDRESS;
            
        if(buttonRelease == 1u)
        {
            /* Toggled for every button press */
            controlBit ^= 1u;
        }
        command = SYSTEM_COMMAND_0;
        previousCommand = command;
        buttonRelease = 0u;        
        buttonState = 1u;
    }
}


/*******************************************************************************
* Function Name: CY_ISR(RELEASE)
********************************************************************************
*
* Summary:
*  ISR for the button release
*
* Parameters:
*  None.
* 
* Return: 
*  None.
*
*******************************************************************************/
CY_ISR(RELEASE)
{   
    buttonRelease = 1u;
}


/*******************************************************************************
* Function Name: CY_ISR(DR_ISR)
********************************************************************************
*
* Summary:
*  Interrupt for data packet and implementing Machester coding.
*
* Parameters:
*  None.
* 
* Return: 
*  None.
*
*******************************************************************************/
CY_ISR(DR_ISR)
{   
    static uint8 packetSequence = 0u;
    static uint8 firstHalf = 1u;
    static uint8 i = 0u;
    
    if(buttonState)
    {
        /* Turn off the LED briefly for each bit in the packet */
        ControlReg_Write(0u);
                
        /* Outputs each segment of the packet as manchester encoded data */
        switch(packetSequence)
        {
            case 0:
                /* Start bit */
                if(firstHalf)
                {
                    /* Start bit is always 1 */
                    transmitState = 0u;
                    firstHalf = 0u;
                }
                else
                {
                    transmitState = startBit;
                    packetSequence = 1u;
                    firstHalf = 1u;
                }
                break;
            case 1:
                /* Field bit */
                if(firstHalf)
                {
                    transmitState = (fieldBit == 1u) ? 0u : 1u;
                    firstHalf = 0u;
                }
                else
                {
                    transmitState = (fieldBit == 1u) ? 1u : 0u;
                    packetSequence = 2u;
                    firstHalf = 1u;
                }
                break;
            case 2:
                /* Control bit */
                if(firstHalf)
                {
                    transmitState = (controlBit == 1u) ? 0u : 1u;
                    firstHalf = 0u;
                }
                else
                {
                    transmitState = (controlBit == 1u) ? 1u : 0u;
                    packetSequence = 3u;
                    firstHalf = 1u;
                }
                break;
            case 3:
                /* Address bits */
                if(firstHalf)
                {
                    /* Extract the pertinent bit */
                    addressBit = (address & ADDRESS_MASK) >> ADDRESS_SHIFT;
                    address = address << 1u;
                    
                    transmitState = (addressBit == 1u) ? 0u : 1u;
                    firstHalf = 0u;
                }
                else
                {
                    transmitState = (addressBit == 1u) ? 1u : 0u;
                    firstHalf = 1u;
                    i++;
                    
                    if (i == 5u)
                    {
                        packetSequence = 4u;
                        i = 0u;
                    }
                }
                break;
            case 4:
                /* Command bits */
                if(firstHalf)
                {
                    /* Extract the pertinent command bit */
                    commandBit = (command & COMMAND_MASK) >> COMMAND_SHIFT;
                    command = command << 1u;
                    
                    transmitState = (commandBit == 1u) ? 0u : 1u;
                    firstHalf = 0u;
                }
                else
                {
                    transmitState = (commandBit == 1u) ? 1u : 0u;
                    firstHalf = 1u;
                    i++;
                    
                    if (i == 6u)
                    {
                        packetSequence = 5u;
                        i = 0u;
                    }
                }
                break;
            case 5:
                /* Turn off LED and disable transmission */
                ControlReg_Write(0u);
                buttonState = 0u;
                packetSequence = 0u;
                transmitState = 0u;
                firstHalf = 1u;
                /* Need to wait 89 ms (89 + 25 = 114) before next transmission */
                CyDelay(89);
                break;
            default:
                /* Turn off LED and disable transmission */
                ControlReg_Write(0u);
                buttonState = 0u;
                packetSequence = 0u;
                transmitState = 0u;
                firstHalf = 1u;
                break;
        }
        ControlReg_Write(transmitState);
    }
    else
    {
        ControlReg_Write(0u);
        packetSequence = 0u;
        transmitState = 0u;
        firstHalf = 1u;
        i=0;
    }
}


/*******************************************************************************
* Function Name: CapSense_SendCommand
********************************************************************************
* Summary:
*  Function to send volume control commands from Capsense.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void CapSense_SendCommand(void)
{
    /* Find Slider Position */
    curPos = CapSense_CSD_GetCentroidPos(CapSense_CSD_LINEARSLIDER0__LS);
    
    /* Give command if it is not currently transmitting. */
    if((buttonState != 1u) && (!capsenseInitial))
    {
        address = TARGET_ADDRESS;

        /* Increase volume */
        if (curPos > oldPos)
        {
            if(previousCommand != SYSTEM_COMMAND_1)
            {
                controlBit ^= 1u;
            }
            command = SYSTEM_COMMAND_1;
            previousCommand = command;
            buttonState = 1u;
        }
        /* Decrease volume */
        else if (curPos < oldPos)
        {
            if(previousCommand != SYSTEM_COMMAND_2)
            {
                controlBit ^= 1u;
            }
            command = SYSTEM_COMMAND_2;
            previousCommand = command;
            buttonState = 1u;
        }
    }
    
    oldPos = curPos;
    capsenseInitial = 0u;
}

void main()
{	
    /* Enable variable used to prevent unintended
       transmission at start-up. */
    capsenseInitial = 1u;
    
    DataRate_Timer_Start();
    PulseCode_Timer_Start();
    CapSense_CSD_Start();
        
    /* Button interrupts */
    button_isr_Start();
    button_isr_SetVector(BRIGHTNESS);
    button_Release_Start();
    button_Release_SetVector(RELEASE);
    
    /* Manchester coding interrupt */
    dr_isr_Start();
    dr_isr_SetVector(DR_ISR);

    /* Enable global interrupts */
    CyGlobalIntEnable;

    /* Initialize baselines */ 
    CapSense_CSD_InitializeAllBaselines();
    
    while(1u)
    {        
        /* Update all baselines */
        CapSense_CSD_UpdateEnabledBaselines();
        
   		/* Start scanning all enabled sensors */
    	CapSense_CSD_ScanEnabledWidgets();
    
        /* Wait for scanning to complete */
		while(CapSense_CSD_IsBusy() != 0);

		/* Check to see if a command is detected */
        CapSense_SendCommand();
    }
}

/* [] END OF FILE */

